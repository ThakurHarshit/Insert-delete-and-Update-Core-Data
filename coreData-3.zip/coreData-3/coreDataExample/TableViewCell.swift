//
//  TableViewCell.swift
//  SaveDataInCore
//
//  Created by Harshit Rana on 1/29/19.
//  Copyright © 2019 Harshit Rana. All rights reserved.
//

import UIKit

@available(iOS 10.0, *)
class TableViewCell: UITableViewCell {

 
    @IBOutlet weak var email: UILabel!
    @IBOutlet weak var username: UILabel!
    @IBOutlet weak var password: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

   
}
