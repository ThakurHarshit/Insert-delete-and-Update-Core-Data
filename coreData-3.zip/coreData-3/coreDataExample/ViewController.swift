//
//  ViewController.swift
//  coreData
//
//  Created by Harshit Rana on 1/29/19.
//  Copyright © 2019 Harshit Rana. All rights reserved.
//

import UIKit
import CoreData

@available(iOS 10.0, *)
class ViewController: UIViewController {
    
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var email: UITextField!
    let nscontext = ((UIApplication.shared.delegate) as! AppDelegate).persistentContainer.viewContext
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
  
    override func viewDidLoad() {
        super.viewDidLoad()
        
    
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
  
    @IBAction func addData(_ sender: UIButton) {

        
        let entity = NSEntityDescription.insertNewObject(forEntityName: "User", into: nscontext)
        
        entity.setValue(username.text!, forKey: "username")
        entity.setValue(password.text!, forKey: "password")
        entity.setValue(email.text!, forKey: "email")
        
        do
        {
            try nscontext.save()
            username.text = ""
            email.text = ""
            password.text = ""
            
        }
        catch
        {
            
        }

        
        let controller = storyboard?.instantiateViewController(withIdentifier: "TableVC") as! TableVC
        navigationController?.pushViewController(controller, animated: true)
        
        
    }
    
}



