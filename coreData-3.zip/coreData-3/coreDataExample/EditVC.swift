//
//  EditVC.swift
//  coreDataExample
//
//  Created by Harshit Rana on 2/11/19.
//  Copyright © 2019 Harshit Rana. All rights reserved.
//

import UIKit
import CoreData
var getrecord = NSManagedObject()

@available(iOS 10.0, *)
class EditVC: UIViewController {

    @IBOutlet weak var txtusername: UITextField!
    
    @IBOutlet weak var txtpassword: UITextField!
    
    @IBOutlet weak var txtemail: UITextField!
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        txtusername.text = getrecord.value(forKey: "username") as? String
        txtpassword.text = getrecord.value(forKey: "password") as? String
        txtemail.text = getrecord.value(forKey: "email") as? String
        

        // Do any additional setup after loading the view.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    @IBAction func tapupdate(_ sender: UIButton) {
        
        let context = appDelegate.persistentContainer.viewContext
        let entitidec = NSEntityDescription.entity(forEntityName: "User", in: context)
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "User")
        request.entity = entitidec
        let pred = NSPredicate(format: "username =%@", txtusername.text!)
        request.predicate = pred
        do {
            let result = try context.fetch(request)
            if result.count > 0 {
                let manage = result[0] as! NSManagedObject
                manage.setValue(txtusername.text!, forKey: "username")
                manage.setValue(txtpassword.text!, forKey: "password")
                manage.setValue(txtemail.text!, forKey: "email")
                
                try context.save()
              // self.dismiss(animated: true, completion: nil)
                self.navigationController?.popViewController(animated: true)
            }
            else{
                print("Record Not Found")
            }
        } catch  {
        }
        
        
        
    }
    
 

}
