//
//  TableVC.swift
//  SaveDataInCore
//
//  Created by Harshit Rana on 1/29/19.
//  Copyright © 2019 Harshit Rana. All rights reserved.
//

import UIKit
import CoreData

@available(iOS 10.0, *)

class TableVC: UIViewController {
    
    @IBOutlet weak var tblVw: UITableView!
   
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    var item :[Any] = []
 

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tblVw.delegate = self
        tblVw.dataSource = self
    
        let context = appDelegate.persistentContainer.viewContext
        var locations  = [User]() // Where Locations = your NSManaged Class
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "User")
        fetchRequest.returnsObjectsAsFaults = false
        locations = try! context.fetch(fetchRequest) as! [User]
        for location in locations
        {
            item.append(location)
        }
        print(item)
        
    }

    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(true)
     
        self.tblVw.reloadData()
    }
    
}

@available(iOS 10.0, *)
extension TableVC: NSFetchedResultsControllerDelegate {

    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tblVw.beginUpdates()
    }

    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tblVw.endUpdates()

        //updateView()
    }

    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {

        switch (type) {
        case .insert:
            if let indexPath = newIndexPath {
                tblVw.insertRows(at: [indexPath], with: .fade)
            }
            break;
        case .delete:
            if let indexPath = indexPath {
                tblVw.deleteRows(at: [indexPath], with: .fade)
            }
            break;
        default:
            print("...")
        }
    }

    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange sectionInfo: NSFetchedResultsSectionInfo, atSectionIndex sectionIndex: Int, for type: NSFetchedResultsChangeType) {

    }

}

@available(iOS 10.0, *)
extension TableVC: UITableViewDataSource {

    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return item.count
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cIdentifier", for: indexPath) as! TableViewCell
        let dic = item[indexPath.row]  as! NSManagedObject
        cell.username?.text = dic.value(forKey: "username" ) as? String
        cell.password?.text = dic.value(forKey: "password" )  as? String
        cell.email?.text = dic.value(forKey: "email" )  as? String
        return cell
    }
    
    
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool
    {
        return true
    }
    
    
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]?
    {
        let editAction = UITableViewRowAction(style: .default, title: "Edit", handler: { (action, indexPath) in
            
             let VC = self.storyboard?.instantiateViewController(withIdentifier: "EditVC") as! EditVC
            let temp = self.item[indexPath.row] as! NSManagedObject
             getrecord = temp
            self.navigationController?.pushViewController(VC, animated: true)
            
            
                    })
        
                    let deleteAction = UITableViewRowAction(style: .default, title: "Delete", handler: { (action, indexPath) in
            
                        let context = self.appDelegate.persistentContainer.viewContext
                        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "User")

                        do
                        {
                            let result = try context.fetch(request)
                            
                            if result.count > 0
                            {
                                let temp = result[indexPath.row] as! NSManagedObject
                                context.delete(temp)

                                print("Record Deleted")
                            }
                            else
                            {
                                print("Record Not Found")
                            }
                        }
                        catch {}
                        self.item.remove(at: indexPath.row)
                        self.tblVw.deleteRows(at: [indexPath], with: .middle)
                        self.tblVw.reloadData()
            
                        // Saving the Delete operation
                        do {
                            try context.save()
                        } catch {
                            print("Failed saving")
                        }
            
                    })
        
                    return [deleteAction,editAction]
        
    }
    

}

@available(iOS 10.0, *)
extension TableVC: UITableViewDelegate {
    

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 130
    }
    
}
